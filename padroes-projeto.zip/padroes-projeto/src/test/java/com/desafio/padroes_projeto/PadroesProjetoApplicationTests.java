package com.desafio.padroes_projeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PadroesProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
